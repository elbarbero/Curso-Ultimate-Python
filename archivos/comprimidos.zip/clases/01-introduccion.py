mensaje = "Hola mundo"
print(type(mensaje))