try:
    n1 = int(input("Ingresa el primer número: "))
except:
    print("Upps, ocurrió un error :(")