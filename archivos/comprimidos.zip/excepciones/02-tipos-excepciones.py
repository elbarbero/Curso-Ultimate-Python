try:
    n1 = int(input("Ingresa el primer número: "))
    heqoiwej
except ValueError as e:
    print("Ingrese un valor que sea correcto")
    print(e)
except NameError as e:
    print("Ocurrió un error")
    print(e)