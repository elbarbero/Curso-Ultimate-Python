import math

print(round(1.3))
print(round(1.3))
print(round(1.3))
print(abs(-77))
print(abs(77))

print(math.ceil(1.12))
print(math.floor(1.999999))
print(math.isnan(23))
print(math.isnan(2/5))
print(math.pow(20, 3))
print(math.sqrt(9))

# https://docs.python.org/3/library/math.html