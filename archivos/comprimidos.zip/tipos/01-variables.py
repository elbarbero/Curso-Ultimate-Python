nombre_curso = "Ultimate Python" # variable tipo string
nombre1 = "Hola" # variable tipo string
NOMBRE_CURSO = "Mundo" # variable tipo string
NoMbRe_CuRsO = "Chanchito" # variable tipo string
NombreCurso = "Feliz" # variable tipo string
print(nombre_curso, nombre1, NOMBRE_CURSO)
alumnos = 5000 # variable tipo integer
puntaje = 9.9 # variable tipo float
publicado = True # variable tipo boolean