nombre = "Nicolas"
apellido = "Schrumann"
nombre_completo1 = nombre + " " + apellido
print(nombre_completo1)
nombre_completo2 = f"{nombre} {apellido}"
print(nombre_completo2)
nombre_completo3 = f"{nombre[0]} {2+5}"
print(nombre_completo3)