from os.path import basename

def guardar():
    print("Guardando impuesto")

def pagar_impuestos():
    print(f"Pagando impuestos desde {basename(__file__)}")