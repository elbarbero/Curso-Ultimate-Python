import os

def guardar():
    print("Guardando accion")

def pagar_acciones():
    print(f"Pagando acciones desde {os.path.basename(__file__)}")