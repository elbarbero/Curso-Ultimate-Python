edad = 15

mensaje = "Es mayor" if edad > 17 else "es menor"

# if edad > 17:
#     mensaje = "Es mayor"
# else:
#     mensaje = "Es menor"

print(mensaje)