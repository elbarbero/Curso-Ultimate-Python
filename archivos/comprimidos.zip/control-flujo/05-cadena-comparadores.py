edad = 25

if edad >= 25 and edad <= 65:
    print("Puede entrar a la piscina")

if 15 <= edad <= 65:
    print("Puede entrar a la piscina tambien")