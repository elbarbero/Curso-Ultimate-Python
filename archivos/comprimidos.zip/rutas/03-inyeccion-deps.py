class Perro:
    def __init__(self, Correa):
        self.correa = Correa