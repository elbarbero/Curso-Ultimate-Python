mascotas = ["Pelusa", "Wolfgang", "Felipe", "Wolfgang", "Chanchito Feliz"]

print(mascotas.count("Wolfgang"))
if "Wolfgang" in mascotas:
    print(mascotas.index("Wolfgang"))