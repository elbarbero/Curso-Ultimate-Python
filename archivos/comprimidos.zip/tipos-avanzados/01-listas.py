numeros = [1, 2, 3]
letras = ["a", "b", "c"]
palabras = ["Chanchito", "Feliz"]
booleans = [True, False, False, True]
matriz = [[0, 1], [1, 0]]
ceros = [0] * 10
cerosUnos = [0, 1] * 10
alfanumericos = numeros + letras
rango = list(range(10))
rango2 = list(range(2, 51))
chars = list("hola mundo")

print(chars)